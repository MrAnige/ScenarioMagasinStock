package entity;

public class Transaction {
	private int id;
	private String nomArticle;
	private int typeDeTransaction;
	private String lieuDestination;
	private String lieuOrigine;
	private int quantite;
	private String reference;
	
	public Transaction(int id, String nomArticle, int typeDeTransaction, String lieuDestination, String  lieuOrigine, int quantite, String reference) {
		this.id=id;
		this.nomArticle=nomArticle;
		this.typeDeTransaction=typeDeTransaction;
		this.lieuDestination=lieuDestination;
		this.lieuOrigine=lieuOrigine;
		this.quantite=quantite;
		this.reference=reference;
		
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNomArticle() {
		return nomArticle;
	}
	public void setNomArticle(String nomArticle) {
		this.nomArticle = nomArticle;
	}
	public int getTypeDeTransaction() {
		return typeDeTransaction;
	}
	public void setTypeDeTransaction(int typeDeTransaction) {
		this.typeDeTransaction = typeDeTransaction;
	}
	public String getLieuDestination() {
		return lieuDestination;
	}
	public void setLieuDestination(String lieuDestination) {
		this.lieuDestination = lieuDestination;
	}
	public String getLieuOrigine() {
		return lieuOrigine;
	}
	public void setLieuOrigine(String lieuOrigine) {
		this.lieuOrigine = lieuOrigine;
	}
	public int getQuantite() {
		return quantite;
	}
	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	
	
		


}
