package entity;

public class Article extends Stock{
	private int id;
	private String nom;
	private String typeArticle;
	public Article(int id, String nom, String typeArticle, int id2, String nom2) {
		super(id2, nom2);
		this.id = id;
		this.nom = nom;
		this.typeArticle = typeArticle;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getTypeArticle() {
		return typeArticle;
	}
	public void setTypeArticle(String typeArticle) {
		this.typeArticle = typeArticle;
	}

}
