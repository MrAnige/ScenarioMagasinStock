package application;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import service.DerbyExportCSV;
import service.InsertTransaction;

public class Controller implements Initializable {
	
	ObservableList<String> typeMouvList = FXCollections.observableArrayList("ENTREE","SORTIE", "TRANSFERT");
	
	@FXML
	private TextField articlField;
	
	@FXML
	private ChoiceBox<String> mouvTypeDropDown;
	
	@FXML
	private TextField originStockField;
	
	@FXML
	private TextField destStockField;
	
	@FXML
	private TextField quantityField;
		
	@FXML
	private Button cancelButton;
	
	@FXML
	private Button validateButton;
	
	@FXML
	private Button exportButton;
	
	@FXML
	private Text originStockText;
	
	@FXML
	private Text destStockText;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// Init values dropDown 
		mouvTypeDropDown.setItems(typeMouvList);
		
		// dropdown fonctionnality with value selected
		mouvTypeDropDown.setOnAction(event -> {			
			switch(mouvTypeDropDown.getValue()) {
				case "ENTREE":
					this.destStockText.setStyle("visibility : visible");
					this.destStockField.setStyle("visibility : visible");
					this.originStockText.setStyle("visibility: hidden;");
					this.originStockField.setStyle("visibility: hidden;");
					break;
				case "SORTIE":
					this.destStockText.setStyle("visibility : hidden");
					this.destStockField.setStyle("visibility : hidden");
					this.originStockText.setStyle("visibility: visible;");
					this.originStockField.setStyle("visibility: visible;");
					break;
				default:
					this.destStockText.setStyle("visibility : visible");
					this.destStockField.setStyle("visibility : visible");
					this.originStockText.setStyle("visibility: visible;");
					this.originStockField.setStyle("visibility: visible;");
					break;
			}
		});
	}
	
	public void cancelButton() {
		articlField.clear();
		originStockField.clear();
		destStockField.clear();
		quantityField.clear();
		mouvTypeDropDown.setValue("");
	}
	
	public void validateButton() throws ClassNotFoundException, SQLException {
		
		try {
			int move = 5;
			
			if(this.mouvTypeDropDown.getValue() != null) {
				// process mouvement value
				switch(this.mouvTypeDropDown.getValue()) {
				case "ENTREE":
					move = 0;
					this.originStockField.clear();
					break;
				case "SORTIE":
					move = 1;
					this.destStockField.clear();
					break;
				case "TRANSFERT":
					move = 2;
					break;
				}
				
				// process transfert mouvement
				if(this.destStockField.getText() != null && this.originStockField.getText() != null && this.mouvTypeDropDown.getValue().equals("TRANSFERT")) {
					if(this.destStockField.getText().equals(this.originStockField.getText())) {
						this.destStockField.setStyle("-fx-border-color : red;");
						this.originStockField.setStyle("-fx-border-color : red;");
					}
					else {
						InsertTransaction.main(articlField.getText(), move,originStockField.getText(),destStockField.getText(),Integer.parseInt(quantityField.getText()));
						this.cancelButton();
					}
				}
				// process enter mouvement
				else if(this.mouvTypeDropDown.getValue().equals("ENTREE")) {
					if(this.destStockField.getText().equals("")) {
						this.destStockField.setStyle("-fx-border-color : red;");
					}
					else {
						InsertTransaction.main(articlField.getText(), move,originStockField.getText(),destStockField.getText(),Integer.parseInt(quantityField.getText()));
						this.cancelButton();
					}
				}
				// process exit mouvement
				else if(this.mouvTypeDropDown.getValue().equals("SORTIE")) {
					if(this.originStockField.getText().equals("")) {
						this.originStockField.setStyle("-fx-border-color : red;");
					}
					else {
						InsertTransaction.main(articlField.getText(), move,originStockField.getText(),destStockField.getText(),Integer.parseInt(quantityField.getText()));
						this.cancelButton();
					}
				}
			}
			else {
				this.mouvTypeDropDown.setStyle("-fx-border-color : red;");
			}
		}
		catch(NumberFormatException e) {
			System.out.println(e);
			System.out.println("Une valeur n'est pas du bon type de saisi.");
			this.quantityField.setStyle("-fx-border-color : red;");
		}
	}
	
	public void exportButton() {
		DerbyExportCSV.main();
	}
	
	
}
