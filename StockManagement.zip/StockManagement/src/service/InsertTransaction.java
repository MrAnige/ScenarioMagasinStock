package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class InsertTransaction {
	private static String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    private static String URL = "jdbc:derby:cciDB;create=true";
    private static String USERNAME = "";
    private static String PASSWORD = "";

		// TODO Auto-generated constructor stub
		public static void main(String articlField,Integer int1 ,String originStockField, String destStockField, Integer quantityField) throws ClassNotFoundException, SQLException {
			int count = 0;
			 
			Class.forName(DRIVER);
			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
			System.out.println("Connexion à la base de données");
			Statement stmt = conn.createStatement();

			String verifTransaction = "SELECT MAX(ID) FROM transactionn";
			ResultSet rs = stmt.executeQuery(verifTransaction);
			if (rs.next()) {
	            count = rs.getInt(1);
	            System.out.println("Number of rows: " + count);
	        }
			String newTransaction = "INSERT INTO transactionn (id,nomArticle,TypeDeTransaction,LieuDestination,LieuOrigine,Quantite,Reference) "
	          		+ "	VALUES (?, ?, ?, ?, ?, ?, ?)";
			 PreparedStatement insertStmt3 = conn.prepareStatement(newTransaction);
	//			Transaction insTransac = new Transaction(count+1,string,int1,string2,string3,int2,"Fait le "+ currentDate() +" a "+ currentTime());
	         insertStmt3.setInt(1, count+1);
	         insertStmt3.setString(2,articlField);
	         insertStmt3.setInt(3, int1 );
	         insertStmt3.setString(4,originStockField);
	         insertStmt3.setString(5,destStockField);
	         insertStmt3.setInt(6,quantityField);
	         insertStmt3.setString(7,"Fait le "+ currentDate() +" a "+ currentTime() );
	         insertStmt3.executeUpdate();
	         String selectSQL3 = "SELECT * FROM transactionn";
	         Statement selectStmt3 = conn.createStatement();
	         ResultSet rs3 = selectStmt3.executeQuery(selectSQL3);

	         while (rs3.next()) {
	             int id = rs3.getInt("id");
	             int typeTrade = rs3.getInt("TypeDeTransaction");
	             String nomArticle = rs3.getString("nomArticle");
	             String LieuDestination = rs3.getString("LieuDestination");
	             String LieuOrigine = rs3.getString("LieuOrigine");
	             int quantite = rs3.getInt("Quantite");
	             String mouvement = rs3.getString("Reference");
	             System.out.println("id : " + id + ", nomArticle : "+nomArticle+ ", TypeDeTransaction : "+ typeTrade
	             		+ ", LieuDestination : "+ LieuDestination + ", LieuOrigine : "+LieuOrigine + ", quantite : "+quantite
	             		+ ", Référence : "+ mouvement);
	           }
	         
	         rs.close();
	         insertStmt3.close();
	         conn.close();		
	         }
		
		private static String currentTime() {
			LocalTime time = LocalTime.now();
	        System.out.println("Current time: " + time);
	        String timeString = time.toString();
	        String firstFive = timeString.substring(0, 5);
	        String firstFivewithH = firstFive.replace(":", "h");
	        System.out.println("Current time: " + firstFivewithH);
			return firstFivewithH;
		}

		private static LocalDate currentDate() {
			LocalDate date = LocalDate.now();
	        System.out.println("Current date: " + date);
	        return date;

		}    

}
