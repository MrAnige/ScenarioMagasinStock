package service;
import java.io.*;	
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class DerbyExportCSV {
    public static void main() {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
    		// TODO Auto-generated constructor stub
            // Register the driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");

            // Connect to the database
            con = DriverManager.getConnection("jdbc:derby:cciDB;create=true");

            // Create a statement
            stmt = con.createStatement();
            
            // Execute the query
            String sql = "SELECT * FROM transactionn";
            rs = stmt.executeQuery(sql);
            
            // Get the ResultSetMetaData
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();



            // Create a FileWriter
        //    FileWriter fileWriter = new FileWriter(csvName()+".csv");
            PrintWriter writer = new PrintWriter(csvName()+".csv", "UTF-8");
            for (int i = 1; i <= columnCount; i++) {
            	writer.append(rsmd.getColumnName(i));
                if (i < columnCount) {
                	writer.append(";");
                }
            }
            writer.append("\n");

            // Write the data to the file
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                	writer.append(rs.getString(i));
                    if (i < columnCount) {
                    	writer.append(";");
                    }
                }
                writer.append("\n");
            }

            // Close the FileWriter
            writer.flush();
            writer.close();
      //      fileWriter.flush();
       //     fileWriter.close();

        } catch (SQLException | ClassNotFoundException | IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public static String csvName() {
    	
    	String csvName="";
    	
    	LocalDate date = LocalDate.now();
    	String dateString = date.toString();
        String dateForCSV = dateString.replace("-", "");
        
    	LocalTime time = LocalTime.now();
    	String timeString = time.toString();
    	String firstHeight = timeString.substring(0, 8);
    	String timeForCSV = firstHeight.replace(":", "");
    	
    	csvName=dateForCSV+"_"+timeForCSV;
    	return csvName;
    }
}
