package service;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Derby {
	private static String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    private static String URL = "jdbc:derby:cciDB;create=true";
    private static String USERNAME = "";
    private static String PASSWORD = "";

    public Derby() throws ClassNotFoundException {
        try {
        	 Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            
            String deleteTableSQL3 = "DROP TABLE transactionn";
        	PreparedStatement deleteTableStmt3 = conn.prepareStatement(deleteTableSQL3);
        	deleteTableStmt3.executeUpdate();
        	String deleteTableSQL = "DROP TABLE article";
        	PreparedStatement deleteTableStmt = conn.prepareStatement(deleteTableSQL);
        	deleteTableStmt.executeUpdate();
        	String deleteTableSQL2 = "DROP TABLE stock";
        	PreparedStatement deleteTableStmt2 = conn.prepareStatement(deleteTableSQL2);
        	deleteTableStmt2.executeUpdate();

              String createTableSQL = "CREATE TABLE stock (id INTEGER PRIMARY KEY,nom VARCHAR(255))";
              PreparedStatement createTableStmt = conn.prepareStatement(createTableSQL);
              createTableStmt.executeUpdate();

              String insertSQL = "INSERT INTO stock (id, nom) VALUES (?, ?)";
              PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
              insertStmt.setInt(1, 1);
              insertStmt.setString(2, "Toulouse");
              insertStmt.executeUpdate();

              insertStmt.setInt(1, 2);
              insertStmt.setString(2, "Castres");
              insertStmt.executeUpdate();
              
              insertStmt.setInt(1, 3);
              insertStmt.setString(2, "Albi");
              insertStmt.executeUpdate();

              insertStmt.setInt(1, 4);
              insertStmt.setString(2, "Lavaur");
              insertStmt.executeUpdate();
              
              insertStmt.setInt(1, 5);
              insertStmt.setString(2, "Montpellier");
              insertStmt.executeUpdate();

              insertStmt.setInt(1, 6);
              insertStmt.setString(2, "Montauban");
              insertStmt.executeUpdate();

              System.out.println("Enregistrements ajoutés avec succès !");

              String selectSQL = "SELECT * FROM stock";
              Statement selectStmt = conn.createStatement();
              ResultSet rs = selectStmt.executeQuery(selectSQL);

              while (rs.next()) {
                int id = rs.getInt("id");
                String nom = rs.getString("nom");
                System.out.println("id : " + id + ", nom : " + nom);
              }

              rs.close();
              selectStmt.close();
              insertStmt.close();
              createTableStmt.close();
              conn.close();
              
              Class.forName(DRIVER);
              Connection conn2 = DriverManager.getConnection(URL, USERNAME, PASSWORD);
              
              String createTableSQL2 = "CREATE TABLE article (id INTEGER PRIMARY KEY,nom VARCHAR(255),typeArticle VARCHAR(255),"
              		+ "idLieu INTEGER REFERENCES stock (id), LieuActuel VARCHAR(255))";
              PreparedStatement createTableStmt2 = conn2.prepareStatement(createTableSQL2);
              createTableStmt2.executeUpdate();

              String insertSQL2 = "INSERT INTO article (id, nom, typeArticle , idLieu, LieuActuel) VALUES (?, ?, ? , ?, ?)";
              PreparedStatement insertStmt2 = conn2.prepareStatement(insertSQL2);
              insertStmt2.setInt(1, 1);
              insertStmt2.setString(2, "Canette de coca");
              insertStmt2.setString(3, "Consommable");
              insertStmt2.setInt(4,5);
              insertStmt2.setString(5,"Produits ménagers");
              insertStmt2.executeUpdate();

              insertStmt2.setInt(1, 2);
              insertStmt2.setString(2, "Abricot");
              insertStmt2.setString(3, "Consommable");
              insertStmt2.setInt(4,4);
              insertStmt2.setString(5,"Lingerie");
              insertStmt2.executeUpdate();
              
              insertStmt2.setInt(1, 3);
              insertStmt2.setString(2, "T-shirt");
              insertStmt2.setString(3, "Utilitaire");
              insertStmt2.setInt(4,1);
              insertStmt2.setString(5,"Viande");
              insertStmt2.executeUpdate();

              insertStmt2.setInt(1, 4);
              insertStmt2.setString(2, "Steak Haché");
              insertStmt2.setString(3, "Consommable");
              insertStmt2.setInt(4,5);
              insertStmt2.setString(5,"Viande");
              insertStmt2.executeUpdate();
              
              insertStmt2.setInt(1, 5);
              insertStmt2.setString(2, "Courgette");
              insertStmt2.setString(3, "Consommable");
              insertStmt2.setInt(4,3);
              insertStmt2.setString(5,"Legume");
              insertStmt2.executeUpdate();

              insertStmt2.setInt(1, 6);
              insertStmt2.setString(2, "Serpillère");
              insertStmt2.setString(3, "Utilitaire");
              insertStmt2.setInt(4,6);
              insertStmt2.setString(5,"Soda");
              insertStmt2.executeUpdate();
              
              

              System.out.println("Enregistrements ajoutés avec succès !");
              

              String selectSQL2 = "SELECT * FROM article";
              Statement selectStmt2 = conn2.createStatement();
              ResultSet rs2 = selectStmt2.executeQuery(selectSQL2);

              while (rs2.next()) {
                int id = rs2.getInt("id");
                String nom = rs2.getString("nom");
                String typeArticle = rs2.getString("typeArticle");
                int idLieu = rs2.getInt("idLieu");
                String lieuActuel = rs2.getString("LieuActuel");
                System.out.println("id : " + id + ", nom : " + nom + "TypeArticle : " + typeArticle + "idLieu : " + idLieu + "lieuActuel : "+lieuActuel);
              }

              rs2.close();
              selectStmt2.close();
              insertStmt2.close();
              createTableStmt2.close();
              conn2.close();
              
              
              Class.forName(DRIVER);
              Connection conn3 = DriverManager.getConnection(URL, USERNAME, PASSWORD);
              
              String createTableSQL3 = "CREATE TABLE transactionn (id INTEGER PRIMARY KEY, nomArticle VARCHAR(255),"
              		+ "TypeDeTransaction INTEGER, LieuDestination VARCHAR(255), LieuOrigine VARCHAR(255),"
              		+ "Quantite INTEGER, Reference VARCHAR(255))";
              PreparedStatement createTableStmt3 = conn3.prepareStatement(createTableSQL3);
              createTableStmt3.executeUpdate();

              String insertSQL3 = "INSERT INTO transactionn (id,nomArticle,TypeDeTransaction,LieuDestination,LieuOrigine,Quantite,Reference) "
              		+ "	VALUES (?, ?, ?, ?, ?, ?, ?)";
              PreparedStatement insertStmt3 = conn3.prepareStatement(insertSQL3);
              insertStmt3.setInt(1, 1);
              insertStmt3.setString(2,"Courgette");
              insertStmt3.setInt(3, 2);
              insertStmt3.setString(4,"Toulouse");
              insertStmt3.setString(5,"Castres");
              insertStmt3.setInt(6,6);
              insertStmt3.setString(7,"Fait le 2022-12-22 a 16h06");
              insertStmt3.executeUpdate();

              insertStmt3.setInt(1, 2);
              insertStmt3.setString(2,"Fraise");
              insertStmt3.setInt(3, 2);
              insertStmt3.setString(4,"Agen");
              insertStmt3.setString(5,"Castres");
              insertStmt3.setInt(6,15);
              insertStmt3.setString(7,"Fait le 2022-12-25 a 10h02");
              insertStmt3.executeUpdate();
              
              insertStmt3.setInt(1, 3);
              insertStmt3.setString(2,"Pomme");
              insertStmt3.setInt(3, 0);
              insertStmt3.setString(4,"Agen");
              insertStmt3.setString(5,"");
              insertStmt3.setInt(6,15);
              insertStmt3.setString(7,"Fait le 2023-01-02 a 08h30");
              insertStmt3.executeUpdate();
              
              insertStmt3.setInt(1, 4);
              insertStmt3.setString(2,"Poire");
              insertStmt3.setInt(3, 1);
              insertStmt3.setString(4,"");
              insertStmt3.setString(5,"Lyon");
              insertStmt3.setInt(6,40);
              insertStmt3.setString(7,"Fait le 2023-01-10 a 19h07");
              insertStmt3.executeUpdate();
              
              insertStmt3.setInt(1, 5);
              insertStmt3.setString(2,"Meringue");
              insertStmt3.setInt(3, 1);
              insertStmt3.setString(4,"");
              insertStmt3.setString(5,"Toulouse");
              insertStmt3.setInt(6,150);
              insertStmt3.setString(7,"Fait le 2023-01-12 a 08h26");
              insertStmt3.executeUpdate();
              
              insertStmt3.setInt(1, 6);
              insertStmt3.setString(2,"Banane");
              insertStmt3.setInt(3, 0);
              insertStmt3.setString(4,"Lille");
              insertStmt3.setString(5,"");
              insertStmt3.setInt(6,15);
              insertStmt3.setString(7,"Fait le 2023-01-23 a 14h48");
              insertStmt3.executeUpdate();

              System.out.println("Enregistrements ajoutés avec succès !");
              
              String selectSQL3 = "SELECT * FROM transactionn";
              Statement selectStmt3 = conn3.createStatement();
              ResultSet rs3 = selectStmt3.executeQuery(selectSQL3);

              while (rs3.next()) {
                int id = rs3.getInt("id");
                int typeTrade = rs3.getInt("TypeDeTransaction");
                String nomArticle = rs3.getString("nomArticle");
                String LieuDestination = rs3.getString("LieuDestination");
                String LieuOrigine = rs3.getString("LieuOrigine");
                int quantite = rs3.getInt("Quantite");
                String mouvement = rs3.getString("Reference");
                System.out.println("id : " + id + ", nomArticle : "+nomArticle+ ", TypeDeTransaction : "+ typeTrade
                		+ ", LieuDestination : "+ LieuDestination + ", LieuOrigine : "+LieuOrigine + ", quantite : "+quantite
                		+ ", Référence : "+ mouvement);
              }

              rs3.close();
              selectStmt3.close();
              insertStmt3.close();
              createTableStmt3.close();
              conn3.close();
              
              
              
        } catch (SQLException e) {
              e.printStackTrace();
        }
    }
    
    public void ConnectBD() {
    	try {
            Class.forName(DRIVER);
            Connection cn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Connexion à la base de données");

        }
        catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    	catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    
}